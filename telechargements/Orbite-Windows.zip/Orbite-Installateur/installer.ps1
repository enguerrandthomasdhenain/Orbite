# Installateur Orbite pour Windows.
# 1. Telecharge le moteur Electron officiel depuis GitHub (electron/electron) et verifie son empreinte SHA-256.
# 2. Ouvre l'installateur graphique (dossier "fichiers\installer"), qui copie Orbite et cree les raccourcis.
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$V = '45.2.3'
$arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'x64' }
$here = $PSScriptRoot
$W = Join-Path $env:TEMP ('orbite-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $W | Out-Null
try {
  Write-Host "Telechargement du moteur Electron $V ($arch, environ 110 Mo)..."
  $base = "https://github.com/electron/electron/releases/download/v$V"
  $zip = "electron-v$V-win32-$arch.zip"
  Invoke-WebRequest -UseBasicParsing -Uri "$base/$zip" -OutFile "$W\e.zip"
  Invoke-WebRequest -UseBasicParsing -Uri "$base/SHASUMS256.txt" -OutFile "$W\sums.txt"
  $expected = (Get-Content "$W\sums.txt" | Where-Object { $_ -like "*$zip" } | ForEach-Object { ($_ -split '\s+')[0] }) | Select-Object -First 1
  $actual = (Get-FileHash "$W\e.zip" -Algorithm SHA256).Hash.ToLower()
  if (-not $expected -or $expected -ne $actual) { throw 'Le moteur est arrive incomplet. Relance l installation.' }
  Write-Host 'Decompression...'
  Expand-Archive -LiteralPath "$W\e.zip" -DestinationPath "$W\engine"
  Write-Host 'Ouverture de l installateur...'
  $env:ORBITE_PAYLOAD = Join-Path $here 'fichiers'
  $env:ORBITE_ENGINE = "$W\engine"
  Start-Process -FilePath "$W\engine\electron.exe" -ArgumentList ('"' + (Join-Path $here 'fichiers\installer') + '"') -Wait
  Write-Host 'Termine. Tu peux fermer cette fenetre.'
} catch {
  Write-Host ''
  Write-Host ('Erreur : ' + $_.Exception.Message) -ForegroundColor Red
  Read-Host 'Appuie sur Entree pour fermer'
} finally {
  Remove-Item -LiteralPath $W -Recurse -Force -ErrorAction SilentlyContinue
}
